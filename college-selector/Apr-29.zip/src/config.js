import firebase from "firebase/compat/app";
import "firebase/compat/auth";

const firebaseConfig = {
  apiKey: "AIzaSyAJPYY92u58_82LlAiGlFm02NToVRlCUes",
  authDomain: "college-selector-47e14.firebaseapp.com",
  projectId: "college-selector-47e14",
  storageBucket: "college-selector-47e14.appspot.com",
  messagingSenderId: "339614314067",
  appId: "1:339614314067:web:98430e1841e4d9af2160a6",
  measurementId: "G-BZ5XDX7HFT",
};

export default firebaseConfig;
